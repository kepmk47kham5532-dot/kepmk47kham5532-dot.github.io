        npx -y http-server . -p ${PORT:-3000} -c-1 --cors -s
